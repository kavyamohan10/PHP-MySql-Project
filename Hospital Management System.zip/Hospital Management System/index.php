<!DOCTYPE html>
<html>
    <head>
        <title>Hospital Management System</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body align="center" class="indexbody">
        <h1>Hospital Management System</h1>
        <h2>Welcome to the Home Page</h2>
        <p>Click here to </p>
        <a href ="admit.php"><input type='submit' value="Admit a Patient" id="admitbtn"></a>
        <a href ="search.php"><input type='submit' value='Search for a Patient' id="searchbtn"></a>
        <a href="display.php"><input type='submit'value='Delete, Update, Display Details' id="displaybtn"></a><br><br>
    
</body>
</html>